const global = {
    owner: [7440566161], // ganti jadi id mu
    botToken: "7900393767:AAEHKp2rtE1s5jSZj8PZUqpvmOzlBKCEoO8", //isi make token bot mu
}

module.exports = global;